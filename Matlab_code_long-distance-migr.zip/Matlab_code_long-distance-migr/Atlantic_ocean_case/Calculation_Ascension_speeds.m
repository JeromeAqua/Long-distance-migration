addpath /zhome/98/c/105036/Documents/Master_thesis/THESIS_2/Atlantic/Likelihood_indiv

multiplied = 1;

load Guessed_Ascension.mat

  PXguessed  = cell(100,1); PXtheo = cell(100,1);
  PYguessed  = cell(100,1); PYtheo = cell(100,1);
  WXguessed = cell(100,1); WXtheo = cell(100,1);
  WYguessed = cell(100,1); WYtheo = cell(100,1);
  
N = 100; %Number of different sets of parameters
initx = -14.5; %datasample([-1.5,0,1],N); %Origin of the departure of the organism  -trying with a new one
inity = -7.9;
load generated.mat
dt = 5; %in hours - dt = 1day now
%Model parameters


D = 0.03; %exp(A + (B-A)*rand(1,N));

%Physical map
dX = 0.5;
[X,Y] = meshgrid(-40:dX:0,-20:dX:0);
X2 = reshape(X,[1,size(X,1)*size(X,2)]);
Y2 = reshape(Y,[1,size(Y,1)*size(Y,2)]);
MAP = [X2;Y2];


% list = [67, 68, 97]
for i=1:100
    [1 i]
    if guessedb(i)>0

    beta = BETA(i);
    gamma = GAMMA(i);
    alpha = ALPHA(i);
    d = D;
    delta = alpha - 1/(2*d*gamma);
    tic
    u = Atlantic10(d,alpha,beta,gamma);
    u = abs(u);
    
    M = isnan(u);
   
    F =  log(u) /delta ;

%      if i ==1
%             imagesc(-40:dX:0,-20:dX:0,F)
%           set(gca,'ydir','normal')
%           hold on
%           plot(initx,inity,'xr')
%      end

        
    [wx,wy] = gradient(F,dX); wx = -1/gamma * wx; wy = -1/gamma * wy;
    wx(isnan(wx))= 0; wx(isinf(wx))= 0;
    wy(isnan(wy))= 0; wy(isinf(wy))= 0;
        
    wx = deg2km(wx); % km/day
    wy = deg2km(wy); % km/day
    wx = wx/24; wy = wy/24; %km /hour
    
    load currents_Ascension.mat
    
    Px = initx;
    Py = inity;
    t = 0;
%         d2 = 3.6*3/7; %km2 / hr
    while t<1500*3; % 3points per day, max 500 days - (~isnan(Px(end)) || ~isnan(Py(end))) && (interp2(X,Y,M,Px(end),Py(end)) < 10^-2) && t<70*24
    t = t+1;
    dBx = 0; %Brownian([0 dt]); dBx = dBx(2); %no diffusivity when recreating the tracks
    dBy = 0; %Brownian([0 dt]); dBy = dBy(2); %no diffusivity when recreating the tracks

    Wx = interp2(X,Y,wx,Px(end),Py(end));
    Wy = interp2(X,Y,wy,Px(end),Py(end));
    
    Vx = multiplied*interp2(long,lat,uo,Px(end),Py(end))*3.6;
    Vy = multiplied*interp2(long,lat,vo,Px(end),Py(end))*3.6;
    
    if isnan(Wx)
        Wx = 0;
    end
    if isnan(Wy)
        Wy = 0;
    end
    if isnan(Vx)
        Vx = 0;
    end
    if isnan(Vy)
        Vy = 0;
    end
    
    [theta, rho] = cart2pol((Vx + Wx)*dt, (Vy + Wy)*dt);
    rho = rho; %in kilometers
    theta = rad2deg(theta); %in degrees
    az = mod(90 - theta, 360); %the azimuth is from the north and going clockwise
     
    
    [py, px] = reckon('rh',Py(end),Px(end),...
                km2deg(rho),az,'degrees'); 
            
    Px = [Px, px]; Py = [Py, py];
    
    end

     PXtheo{i} = Px; 
     PYtheo{i} = Py;
     WXtheo{i} = interp2(X,Y,wx,Px,Py);
     WYtheo{i} = interp2(X,Y,wy,Px,Py);
    

    toc

%      plot(PX{i},PY{i},'k')
%      drawnow
    else
    end
   save Ascension_with_speed.mat
end
    

for i=1:100
    [2 i]
    if guessedb(i)>0

    beta = guessedb(i);
    gamma = guessedg(i);
    alpha = guesseda(i);
    d = D;
    delta = alpha - 1/(2*d*gamma);
    tic
    u = Atlantic10(d,alpha,beta,gamma);
    u = abs(u);
    
    M = isnan(u);
   
    F =  log(u) /delta ;

%      if i ==1
%             imagesc(-40:dX:0,-20:dX:0,F)
%           set(gca,'ydir','normal')
%           hold on
%           plot(initx,inity,'xr')
%      end

        
    [wx,wy] = gradient(F,dX); wx = -1/gamma * wx; wy = -1/gamma * wy;
    wx(isnan(wx))= 0; wx(isinf(wx))= 0;
    wy(isnan(wy))= 0; wy(isinf(wy))= 0;
        
    wx = deg2km(wx); % km/day
    wy = deg2km(wy); % km/day
    wx = wx/24; wy = wy/24; %km /hour
    
    load currents_Ascension.mat
    
    Px = initx;
    Py = inity;
    t = 0;
%         d2 = 3.6*3/7; %km2 / hr
    while t<1500*3; % 3points per day, max 500 days - (~isnan(Px(end)) || ~isnan(Py(end))) && (interp2(X,Y,M,Px(end),Py(end)) < 10^-2) && t<70*24
    t = t+1;
    dBx = 0; %Brownian([0 dt]); dBx = dBx(2); %no diffusivity when recreating the tracks
    dBy = 0; %Brownian([0 dt]); dBy = dBy(2); %no diffusivity when recreating the tracks

    Wx = interp2(X,Y,wx,Px(end),Py(end));
    Wy = interp2(X,Y,wy,Px(end),Py(end));
    
    Vx = multiplied*interp2(long,lat,uo,Px(end),Py(end))*3.6;
    Vy = multiplied*interp2(long,lat,vo,Px(end),Py(end))*3.6;
    
    if isnan(Wx)
        Wx = 0;
    end
    if isnan(Wy)
        Wy = 0;
    end
    if isnan(Vx)
        Vx = 0;
    end
    if isnan(Vy)
        Vy = 0;
    end
    
    [theta, rho] = cart2pol((Vx + Wx)*dt, (Vy + Wy)*dt);
    rho = rho; %in kilometers
    theta = rad2deg(theta); %in degrees
    az = mod(90 - theta, 360); %the azimuth is from the north and going clockwise
     
    
    [py, px] = reckon('rh',Py(end),Px(end),...
                km2deg(rho),az,'degrees'); 
            
    Px = [Px, px]; Py = [Py, py];
    
    end

     PXguessed{i} = Px; 
     PYguessed{i} = Py;
     WXguessed{i} = interp2(X,Y,wx,Px,Py);
     WYguessed{i} = interp2(X,Y,wy,Px,Py);
    

    toc

%      plot(PX{i},PY{i},'k')
%      drawnow
    else
    end
   save Ascension_with_speed.mat
end