function L = Likelihood(D, alpha, beta, gamma, PX, PY, DT)
multiplied = 1;
    delta = alpha - 1/(2*D*gamma);
    
%    if delta > 0
%        L = -10^50;
%    else
   % DT = DT;  %to have it in seconds, correct units
    DT = DT(2:end); %because the first one is 0
    dX = 0.5;
    [X,Y] = meshgrid(-40:dX:0,-20:dX:0);
    X2 = reshape(X,[1,size(X,1)*size(X,2)]);
    Y2 = reshape(Y,[1,size(Y,1)*size(Y,2)]);
    MAP = [X2;Y2];
        
    u = Atlantic10(D,alpha,beta,gamma);
    u = abs(u);
   
    F =  log(u) /delta ;
%     if min(F) < -10^-2
%         L = -10^50;
%     else
    [wx,wy] = gradient(F,dX); %*deg2km(distance(-50:dX:20,0,-50:dX:20,1)),111.1949*dX); 
    wx = -1/gamma * wx ; wy = -1/gamma * wy ;
    wx(isnan(wx))= 0; wx(isinf(wx))= 0;
    wy(isnan(wy))= 0; wy(isinf(wy))= 0;
    
        wx = deg2km(wx)/24; % km/hour
        wy = deg2km(wy)/24; % km/hour
    
   % index = abs(diff(PY)) > 10^(-5); %to remove the points where we are stuck at the coasts, they cause problems
   [a,b] = distance(PY(1:end-1),PX(1:end-1),PY(1:end-1),PX(2:end));
   Distx = deg2km(a.*sign(180-b));
   [a,b] = distance(PY(1:end-1),PX(1:end-1),PY(2:end),PX(1:end-1));
   Disty = deg2km(a.*sign(179 - b));
  
    load currents_Ascension.mat
    Vx = multiplied * interp2(long,lat,uo,PX(1:end-1),PY(1:end-1)) * 3.6; Vx(isnan(Vx)) = 0; %multiplying it by 3.6 to have km/h
    Vy = multiplied * interp2(long,lat,vo,PX(1:end-1),PY(1:end-1)) * 3.6; Vy(isnan(Vy)) = 0;
    
    
    W1 = interp2(X,Y,wx,PX(1:end-1),PY(1:end-1)); W1(isnan(W1)) = 0;  %W1 = W1(index);
    W2 = interp2(X,Y,wy,PX(1:end-1),PY(1:end-1)); W2(isnan(W2)) = 0;%W2 = W2(index);
    
    xx =  Distx - (Vx+W1) .*DT ; %a  - (V + W1)*dt;
    yy =  Disty - (Vy+W2) .*DT; %b  - W2*dt;

    LL = - (xx.^2 + yy.^2);% / (4*D*dt) - log(4 * pi * D * dt); %-(xx.^2 + yy.^2) / (4*D*dt) - log(4*pi*D*dt);
    
    L = sum(LL);
   % end
%    end
    
end