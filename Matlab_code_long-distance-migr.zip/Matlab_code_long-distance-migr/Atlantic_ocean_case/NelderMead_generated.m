%Nelder-Mead algorithm to find the maximum of likelihood of our function

% load list.mat

% 
%    guesseda = []; 
%    guessedb = [];
%    guessedg = [];
  %guessedD = [];

D = 0.03;
% addpath /zhome/98/c/105036/Documents/Master_thesis/THESIS_2/Atlantic/Likelihood_indiv
% load Indiv_normal1_22.mat
load generated_tracks.mat
 
% load guessed_theo.mat
 FNAME = 'guessed_theohpc.mat';
for k = 1:100
    k

    px = PX{k}'; 
    py = PY{k}'; 
    DT = 5*ones(size(PX{k}))'; %TURTLE(:,4);
    
    a = [px, py, DT];
    a = a(~any(isnan(a),2),:); %to remove the NaNs

    px = a(:,1);
    py = a(:,2);
    DT = a(:,3);
    
    

                                     
  try
lik2optimize = @(x) -Likelihood(D,x(1),x(2),x(3),px,py,DT);

options = optimset('Display','iter','MaxFunEvals',3000,'Tolfun',10^-6,'TolX',10^-8);


[X, fval, exitflag, output] = fminsearchbnd(lik2optimize, [0, 1, 1], [min(ALPHA), min(BETA), min(GAMMA)],[max(ALPHA), max(BETA), max(GAMMA)], options);%con(lik2optimize, [1, 1, 1], [], [], [], [], [-100, 10^-1, 10^-1],[+100, +10^1, +10^1],[], options);% [], , options);

guesseda(k) = X(1); %[guesseda, X(1)];
guessedb(k) = X(2); %[guessedb, X(2)];
guessedg(k) = X(3); %[guessedg, X(3)];


save(FNAME)

  catch
    guesseda(k) = 0; %X(1); %[guesseda, -1];
    guessedb(k) = -1; %X(2); %[guessedb, -1];
    guessedg(k) = -1; %X(3); %[guessedg, -1];
 
    save(FNAME)
 end  
end