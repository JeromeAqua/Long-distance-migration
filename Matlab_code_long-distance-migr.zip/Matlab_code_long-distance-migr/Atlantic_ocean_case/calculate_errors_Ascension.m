load Ascension_with_speed.mat

meanWtheoAscension = zeros(100,1);
meanWguessedAscension = zeros(100,1);

for i=1:100
    if ~isnan(LongAscensiontheo(i))
        atheo = WXtheo{i};
        btheo = WYtheo{i};
    
        aguessed = WXguessed{i};
        bguessed = WYguessed{i};
        
        meanWtheoAscension(i) = mean(sqrt(atheo(1:LongAscensiontheo(i)).^2+btheo(1:LongAscensiontheo(i)).^2));
        meanWguessedAscension(i) = mean(sqrt(aguessed(1:LongAscensionguessed(i)).^2+bguessed(1:LongAscensionguessed(i)).^2));    
        
    else
        meanWtheoAscension(i) = NaN;
        meanWguessedAscension(i) = NaN;
    end
    
end

%%
Error_Alpha_Ascension = (guesseda - ALPHA') ./ ALPHA';
Ratio_Ascension_theo = BETA./GAMMA./meanWtheoAscension.^2;
Ratio_Ascension_guessed = guessedb'./guessedg'./meanWguessedAscension.^2;
Error_Ratio_Ascension = (Ratio_Ascension_guessed-Ratio_Ascension_theo)./Ratio_Ascension_theo;

Error_Ratio_Ascension(Error_Ratio_Ascension>10) = 10;