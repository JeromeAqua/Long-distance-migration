beta = 10.^(-2+4*rand(100,1));
gamma = 10.^(-2+4*rand(100,1));
alpha = -10 + 20*rand(100,1);

save generated.mat
