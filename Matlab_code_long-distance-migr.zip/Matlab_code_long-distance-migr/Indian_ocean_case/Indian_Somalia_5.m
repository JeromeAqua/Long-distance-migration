function out = Indian_Somalia_5(d,alph,bet,gam)
%
% Atlantic2.m
%
% Model exported on Apr 26 2017, 18:11 by COMSOL 5.2.0.220.
delt = alph - 1/ (2*d*gam);
d = num2str(d);
alph = num2str(alph);
bet = num2str(bet);
gam = num2str(gam);

import com.comsol.model.*
import com.comsol.model.util.*


model = ModelUtil.create('Model');

model.modelPath('/zhome/98/c/105036/Documents/THESIS_2/Indian/Likeli_indiv');

model.label('Indian_Somalia.mph');

model.comments(['Untitled\n\n']);

model.param.set('alpha', alph);
model.param.set('beta', bet);
model.param.set('gamma', gam);
model.param.set('delta', 'alpha - 1/(2*D*gamma)');
model.param.set('D', d);

model.modelNode.create('comp1');

model.geom.create('geom1', 2);

model.file.create('res1');
model.file.create('res2');

model.func.create('int1', 'Interpolation');
model.func.create('int2', 'Interpolation');
model.func('int1').set('funcs', {'curx' '1'});
model.func('int1').set('nargs', '2');
model.func('int1').set('filename', '/zhome/98/c/105036/Documents/THESIS_2/Indian/CURX_deg3.txt');
model.func('int1').set('source', 'file');
model.func('int2').set('funcs', {'cury' '1'});
model.func('int2').set('nargs', '2');
model.func('int2').set('filename', '/zhome/98/c/105036/Documents/THESIS_2/Indian/CURY_deg3.txt');
model.func('int2').set('source', 'file');

model.mesh.create('mesh1', 'geom1');

model.geom('geom1').label('Geometry');
model.geom('geom1').create('pol1', 'Polygon');
model.geom('geom1').feature('pol1').set('source', 'file');
model.geom('geom1').feature('pol1').set('filename', '/zhome/98/c/105036/Documents/THESIS_2/Indian/Likeli_indiv/Somalia_5.txt');
% model.geom('geom1').create('r1', 'Rectangle');
% model.geom('geom1').feature('r1').set('size', {'1' '2'});
% model.geom('geom1').feature('r1').set('pos', {'53' '-6.5'});
% model.geom('geom1').create('dif1', 'Difference');
% model.geom('geom1').feature('dif1').selection('input2').set({'r1'});
% model.geom('geom1').feature('dif1').selection('input').set({'pol1'});
model.geom('geom1').run;
%model.geom('geom1').run('fin');

model.physics.create('c', 'CoefficientFormPDE', 'geom1');
model.physics('c').create('dir1', 'DirichletBoundary', 1);
model.physics('c').feature('dir1').selection.set([4]); %target
model.physics('c').create('dir2', 'DirichletBoundary', 1);
model.physics('c').feature('dir2').selection.set([2,6,7,8]); %open sea

model.mesh('mesh1').autoMeshSize(2);

model.physics('c').feature('cfeq1').set('c', {'-D' '0' '0' '-D'});
model.physics('c').feature('cfeq1').set('a', 'beta*delta');
model.physics('c').feature('cfeq1').set('f', '0');
model.physics('c').feature('cfeq1').set('da', '0');
model.physics('c').feature('cfeq1').set('be', {'curx(x,y)' 'cury(x,y)'});
model.physics('c').feature('init1').label('Initial value 1');
model.physics('c').feature('dir1').set('r', '1');
if delt < 0
    bc = 0;
else
    bc = 10^5;
end    
model.physics('c').feature('dir2').set('r', num2str(bc));

model.mesh('mesh1').run;

model.study.create('std1');
model.study('std1').create('stat', 'Stationary');

model.sol.create('sol1');
model.sol('sol1').study('std1');
model.sol('sol1').attach('std1');
model.sol('sol1').create('st1', 'StudyStep');
model.sol('sol1').create('v1', 'Variables');
model.sol('sol1').create('s1', 'Stationary');
model.sol('sol1').feature('s1').create('fc1', 'FullyCoupled');
model.sol('sol1').feature('s1').feature.remove('fcDef');

%model.result.dataset.remove('dset1');

model.sol('sol1').attach('std1');
model.sol('sol1').feature('s1').set('stol', '0.0001');
model.sol('sol1').runAll;

dX = 0.1;
    [X,Y] = meshgrid(20:dX:100,-30:dX:20);
    X2 = reshape(X,[1,size(X,1)*size(X,2)]);
    Y2 = reshape(Y,[1,size(Y,1)*size(Y,2)]);
    MAP = [X2;Y2];
    
P = mphinterp(model,'u','coord',MAP);
P = reshape(P,size(X));

out = P;
%mphgeom(model,'geom1','Edgelabels','on') %if we want to see the boundary
%numbers
end