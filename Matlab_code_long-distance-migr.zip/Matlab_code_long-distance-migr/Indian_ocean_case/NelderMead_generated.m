%Nelder-Mead algorithm to find the maximum of likelihood of our function

% load list.mat

% 
%    guesseda = []; 
%    guessedb = [];
%    guessedg = [];
%    guessedD = [];

 
% load guessed_theo.mat
D = 0.03;

load generated_tracks-Indian.mat

 FNAME = 'guessed_theoindian3.mat';
for k = 1:100
    k
    px = PX{k}'; 
    py = PY{k}'; 
    DT = 12*ones(size(PX{k}))'; 
    
    a = [px, py, DT];
    a = a(~any(isnan(a),2),:); %to remove the NaNs

    px = a(:,1);
    py = a(:,2);
    DT = a(:,3);

                                     
 try
lik2optimize = @(x) -Likelihood(D,x(1),x(2),x(3),px,py,DT);

options = optimset('Display','iter','MaxFunEvals',3000,'Tolfun',10^-6,'TolX',10^-6);


[X, fval, exitflag, output] = fminsearchbnd(lik2optimize, [0, 1, 1], [-10, 10^-1, 10^-1],[+10, 10, +10^1], options);%con(lik2optimize, [1, 1, 1], [], [], [], [], [-100, 10^-1, 10^-1],[+100, +10^1, +10^1],[], options);% [], , options);

guesseda(k) = X(1); %[guesseda, X(1)];
guessedb(k) = X(2); %[guessedb, X(2)];
guessedg(k) = X(3); %[guessedg, X(3)];


save(FNAME)

 catch
    guesseda(k) = 0; %X(1); %[guesseda, -1];
    guessedb(k) = -1; %X(2); %[guessedb, -1];
    guessedg(k) = -1; %X(3); %[guessedg, -1];
 
    save(FNAME)
end  
end

