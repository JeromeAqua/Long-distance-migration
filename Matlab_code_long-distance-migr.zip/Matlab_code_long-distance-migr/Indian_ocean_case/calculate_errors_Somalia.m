load Somalia_with_speed.mat

meanWtheoSomalia = zeros(100,1);
meanWguessedSomalia = zeros(100,1);

for i=1:100
    if ~isnan(LongSomaliatheo(i))
        atheo = WXtheo{i};
        btheo = WYtheo{i};
    
        aguessed = WXguessed{i};
        bguessed = WYguessed{i};
        
        meanWtheoSomalia(i) = mean(sqrt(atheo(1:LongSomaliatheo(i)).^2+btheo(1:LongSomaliatheo(i)).^2));
        meanWguessedSomalia(i) = mean(sqrt(aguessed(1:LongSomaliaguessed(i)).^2+bguessed(1:LongSomaliaguessed(i)).^2));    
        
    else
        meanWtheoSomalia(i) = NaN;
        meanWguessedSomalia(i) = NaN;
    end
    
end

%%
Error_Alpha_Somalia = (guesseda - ALPHA') ./ ALPHA';
Ratio_Somalia_theo = BETA./GAMMA./meanWtheoSomalia.^2;
Ratio_Somalia_guessed = guessedb'./guessedg'./meanWguessedSomalia.^2;
Error_Ratio_Somalia = (Ratio_Somalia_guessed-Ratio_Somalia_theo)./Ratio_Somalia_theo;

Error_Ratio_Somalia(Error_Ratio_Somalia>10) = 10;