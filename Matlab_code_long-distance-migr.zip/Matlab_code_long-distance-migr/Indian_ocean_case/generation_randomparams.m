beta = 10.^(-1+2*rand(100,1));
gamma = 10.^(-1+2*rand(100,1));
alpha = -10 + 20*rand(100,1);

save generated.mat
