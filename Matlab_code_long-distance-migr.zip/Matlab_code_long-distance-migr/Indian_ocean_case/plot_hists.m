AA = (guesseda'-ALPHA(1:length(guesseda)))./ALPHA(1:length(guesseda));
% AA = log10(AA.*sign(AA))%sign(AA).*log10(AA.*sign(AA));
subplot(2,2,1)
histogram(AA(guesseda~=0),50)
title('\alpha')

BB = (guessedb'-BETA(1:length(guessedb)))./BETA(1:length(guessedb));
% BB = log10(BB.*sign(BB))%sign(BB).*log10(BB.*sign(BB));
subplot(2,2,2)
histogram(BB(guessedb~=0),100)
title('\beta')


GG = (guessedg'-GAMMA(1:length(guessedg)))./GAMMA(1:length(guessedg));
% GG = log10(GG.*sign(GG))%sign(GG).*log10(GG.*sign(GG));
subplot(2,2,3)
histogram(GG(guessedg~=0),100)
title('\gamma')

RATIO = ((guessedb'./guessedg') - BETA(1:length(guessedg))./GAMMA(1:length(guessedg)))./(BETA(1:length(guessedg))./GAMMA(1:length(guessedg)));
% RATIO = log10(RATIO.*sign(RATIO))%sign(RATIO).*log10(RATIO.*sign(RATIO));
RATIO(RATIO >10) = 10; %to reduce the window
subplot(2,2,4)
histogram(RATIO(guessedg~=0),100)
title('\beta / \gamma')