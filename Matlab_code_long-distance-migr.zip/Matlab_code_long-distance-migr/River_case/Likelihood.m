
function L = Likelihood(alpha, beta, gamma, D, c, PX, PY)

    delta = alpha - 1/(2*D*gamma);
    
    dt = 0.001;
    dX = 0.01;
    [X,Y] = meshgrid(-2:dX:2,0:dX:1);
    X2 = reshape(X,[1,size(X,1)*size(X,2)]);
    Y2 = reshape(Y,[1,size(Y,1)*size(Y,2)]);
    MAP = [X2;Y2];
    vx = @(x,y) c*y + 0;

    
    u = river3(D,alpha,beta,gamma,c,MAP);
    u = reshape(u,size(X));
    u = abs(u);
   
    F =  log(u) /delta ;
    [wx,wy] = gradient(F,dX); wx = -1/gamma * wx; wy = -1/gamma * wy;
    wx(isnan(wx))= 0; wx(isinf(wx))= 0;
    wy(isnan(wy))= 0; wy(isinf(wy))= 0;
    
    index = abs(diff(PY)) > 10^(-5); %to remove the points where we are stuck at the costs, they cause problems
    a = diff(PX); a = a(index);
    b = diff(PY); b = b(index);
    V = vx(PX(1:end-1),PY(1:end-1)); V = V(index);
    W1 = interp2(X,Y,wx,PX(1:end-1),PY(1:end-1)); W1 = W1(index);
    W2 = interp2(X,Y,wy,PX(1:end-1),PY(1:end-1)); W2 = W2(index);
    
    xx =  a / dt - (V+W1) ; %a  - (V + W1)*dt;
    yy =  b / dt - W2; %b  - W2*dt;

    LL = - (xx.^2 + yy.^2); %-(xx.^2 + yy.^2) / (4*D*dt) - log(4*pi*D*dt);
    
    L = sum(LL);
    
end
    
    


    

