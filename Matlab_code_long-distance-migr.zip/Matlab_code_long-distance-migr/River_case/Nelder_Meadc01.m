%Nelder-Mead algorithm to find themaximum of likelihood of our function

load tracksc01.mat
PX = PXc01; PY = PYc01;

guesseda = zeros(100,1)';
guessedb = zeros(100,1)';
guessedg = zeros(100,1)';

for k = 1:100

px = PX{k};
py = PY{k};

lik2optimize = @(x) -Likelihood(x(1),x(2),x(3),D,c,px,py);

options = optimset('Display','iter','MaxFunEvals',900,'Tolfun',10^-7);


[X, fval, exitflag, output] = fminsearchbnd(lik2optimize, [0, 1, 1], [-10, 10^-1, 10^-1], [10, 10^1 10^1], options);

guesseda(k) = X(1);
guessedb(k) = X(2);
guessedg(k) = X(3); 

save NelderMead_c01.mat

end
