dX = 0.01; %creation of the map
[X,Y] = meshgrid(-2:dX:2,0:dX:1);
X2 = reshape(X,[1,size(X,1)*size(X,2)]);
Y2 = reshape(Y,[1,size(Y,1)*size(Y,2)]);
MAP = [X2;Y2];

initx = 0; % starting point
inity = 0.1;

D = 0.1;
% Alpha = [-10 -1 -0.1 0 0.1 1 10];
Beta = [10^-2 10^-1 1 10 100]; %1;
Gamma = [10^-2 10^-1 1 10 100]; %1;

c = 1;
 PXgamma = {}; PYgamma = {}; %creation of the repositories for the trajectories
% PXc10 = PXc1; PYc10 = PXc1;
% PXc01 = {}; PYc01 = {};

vx = @(x,y) c*y + 0;
dt = 0.01;

subplot(131)

for i=1%:size(Gamma,2)
    AAlpha = 10; %Alpha(i);
    BBeta = 1; %Beta(i);
    GGamma = 1;%Gamma(i);
    delta = AAlpha - 1/(2*D*GGamma);
                
    u = river3(D,AAlpha,BBeta,GGamma,c,MAP);
    u = reshape(u,size(X));
    u = abs(u);
    F = log(u)/delta;     
    
    [wx,wy] = gradient(F,dX); wx = -1/GGamma * wx; wy = -1/GGamma * wy;
    wx(isnan(wx))= 0; wx(isinf(wx))= 0;
    wy(isnan(wy))= 0; wy(isinf(wy))= 0;
        

    Px2 = initx;
    Py2 = inity;
    t = 0;
    
        
    while (abs(Px2(end)) > 0.05 || abs(Py2(end)-1) > 0.05) && t<10^3
        t = t+1;

        Wx = interp2(X,Y,wx,Px2(end),Py2(end));
        Wy = interp2(X,Y,wy,Px2(end),Py2(end));
    
        if isnan(Wx)
            Wx = 0;
        end
        if isnan(Wy)
            Wy = 0;
        end
        
        px = Px2(end) + (vx(Px2(end),Py2(end)) + Wx)*dt;
        if px<-2
            px = -2 + abs(px+2);
        elseif px>2
            px = 2 - abs(px-2);       
        end
        Px2 = [Px2, px];
    
        py = Py2(end) + Wy*dt;
        if py < 0
            py = 0;
        elseif py > 1
            py = 1 - abs(py-1);       
        end
        Py2 = [Py2, py];
    
    end

    PXgamma{i} = Px2;
    PYgamma{i} = Py2;
    
    plot(Px2,Py2,'o')
    hold on
    
end

%%
cc = gray(7);
figure
subplot(131)
hold on
for i=1:6
    plot(PXalpha{i},PYalpha{i},'Color',cc(i,:),'Marker','o','MarkerIndices',1:3:length(PXalpha{i}),'LineWidth',1.2)
end

subplot(132)
hold on
for i=1:5
    plot(PXbeta{i},PYbeta{i},'Color',cc(i,:),'Marker','o','MarkerIndices',1:3:length(PXbeta{i}),'LineWidth',1.2)
end

subplot(133)
hold on
for i=1:5
    plot(PXgamma{i},PYgamma{i},'Color',cc(i,:),'Marker','o','MarkerIndices',1:3:length(PXgamma{i}),'LineWidth',1.2)
end

colormap gray(7)
% colorbar
