 COL = [];
 for i=1:5
     y = PYalpha{i}; x = PXalpha{i}; z = zeros(size(x)); 
     COL = [COL, vx(x,y)./sqrt(WXalpha{i}.^2+WYalpha{i}.^2)];
     
     y = PYbeta{i}; x = PXbeta{i};
     COL = [COL, vx(x,y)./sqrt(WXbeta{i}.^2+WYbeta{i}.^2);]
 end
      y = PYalpha{6}; x = PXalpha{6}; z = zeros(size(x)); 
     COL = [COL, vx(x,y)./sqrt(WXalpha{6}.^2+WYalpha{6}.^2)];


figure
subplot(131)

hold on
 a = colormap(flipud(jet));
%  title('\alpha')
  
for i=1:6
%     a = colormap(flipud(jet));
    y = PYalpha{i}; x = PXalpha{i}; z = zeros(size(x)); 
    col = vx(x,y)./sqrt(WXalpha{i}.^2+WYalpha{i}.^2);
    surface([x;x],[y;y],[z;z],[col;col],...
        'facecol','no',...
        'edgecol','interp',...
        'linew',1.2);
    caxis([0 max(max(COL))])
    hold on
    
    for j=1:3:length(x)
        plot(x(j),y(j),'Color',a(max(1,floor((size(a,1)-1)/(max(COL)-min(COL))*col(j)+size(a,1)-max(COL)*(size(a,1)-1)/(max(COL)-min(COL)))),:),'Marker','o','LineWidth',1.2)
    end
end
box on
    
xticks([-0.1 0 0.1])
xlim([-0.1 0.13])
yticks([0.1 0.25 0.5 0.75 1])
subplot(132)
box on

for i=1:5
    y = PYbeta{i}; x = PXbeta{i}; z = zeros(size(x)); 
    col = vx(x,y)./sqrt(WXbeta{i}.^2+WYbeta{i}.^2);
    surface([x;x],[y;y],[z;z],[col;col],...
        'facecol','no',...
        'edgecol','interp',...
        'linew',1.2);
    hold on
    caxis([0 max(max(COL))])
    for j=1:3:length(x)
        plot(x(j),y(j),'Color',a(max(1,floor((size(a,1)-1)/(max(COL)-min(COL))*col(j)+size(a,1)-max(COL)*(size(a,1)-1)/(max(COL)-min(COL)))),:),'Marker','o','LineWidth',1.2)
    end
    
end
xlim([-0.2 0.03])
xticks([-0.2 -0.1 0])
yticks([0.1 0.25 0.5 0.75 1])
subplot(133)

caxis([0 max(max(COL))])
colorbar