function out = river3(d,alph, bet, gam, C, MAP)
%
% river3.m
%
% Model exported on Feb 28 2017, 15:06 by COMSOL 5.2.0.220.
delt = alph - 1/ (2*d*gam);
d = num2str(d);
alph = num2str(alph);
bet = num2str(bet);
gam = num2str(gam);
cc = num2str(C);


import com.comsol.model.*
import com.comsol.model.util.*

model = ModelUtil.create('Model');

model.modelPath('/zhome/98/c/105036/Documents/THESIS');

model.label('river3.mph');

model.comments(['Untitled\n\n']);

model.param.set('beta', bet);%'10');
model.param.set('gamma', gam); %'0.1');
model.param.set('D', d);%'1');
model.param.set('alpha', alph);%'0');
model.param.set('c', cc);
model.param.set('delta', 'alpha - 1/(2*D*gamma)');
model.param.set('offset', '0.1');

model.modelNode.create('comp1');

model.geom.create('geom1', 2);

model.mesh.create('mesh2', 'geom1');

model.geom('geom1').label('River');
model.geom('geom1').create('pol1', 'Polygon');
model.geom('geom1').feature('pol1').set('table', {'-2' '-1';  ...
'2' '-1';  ...
'2' '1';  ...
'0.1' '1';  ...
'-0.1' '1';  ...
'-2' '1'});
model.geom('geom1').feature('pol1').set('source', 'table');
model.geom('geom1').run;

model.physics.create('c', 'CoefficientFormPDE', 'geom1');
model.physics('c').create('zflx2', 'ZeroFluxBoundary', 1);
model.physics('c').feature('zflx2').selection.set([2 3 5]);
model.physics('c').create('dir1', 'DirichletBoundary', 1);
model.physics('c').feature('dir1').selection.set([4]);
model.physics('c').create('dir2', 'DirichletBoundary', 1);
model.physics('c').feature('dir2').selection.set([1 6]);

model.mesh('mesh2').autoMeshSize(1);

model.result.table.create('evl2', 'Table');
model.result.table.create('tbl1', 'Table');
model.result.table.create('tbl2', 'Table');

% model.view('view1').axis.set('abstractviewxscale', '0.0059523810632526875');
% model.view('view1').axis.set('xmax', '2.0833332538604736');
% model.view('view1').axis.set('abstractviewyscale', '0.0059523810632526875');
% model.view('view1').axis.set('abstractviewbratio', '0');
% model.view('view1').axis.set('abstractviewtratio', '0');
% model.view('view1').axis.set('abstractviewrratio', '0.0758928656578064');
% model.view('view1').axis.set('xmin', '-2.0833332538604736');
% model.view('view1').axis.set('abstractviewlratio', '-0.0758928656578064');

model.physics('c').feature('cfeq1').set('c', {'-D' '0' '0' '-D'});
model.physics('c').feature('cfeq1').set('a', 'beta*delta');
model.physics('c').feature('cfeq1').set('f', '0');
model.physics('c').feature('cfeq1').set('da', '0');
model.physics('c').feature('cfeq1').set('be', {'c*y + offset' '0'});
model.physics('c').feature('dir1').set('r', '1');

if delt < 0
    bc = 0;
else
    bc = 10^3;
end    
model.physics('c').feature('dir2').set('r', num2str(bc));


model.mesh('mesh2').run;

model.result.table('evl2').label('Evaluation 2D');
model.result.table('evl2').comments('Interactive 2D values');
model.result.table('tbl1').comments('Global Evaluation 1 (Eval1)');
model.result.table('tbl2').label('Table 2');
model.result.table('tbl2').comments('Global Evaluation 1 (u)');

model.study.create('std1');
model.study('std1').create('stat', 'Stationary');

model.sol.create('sol1');
model.sol('sol1').study('std1');
model.sol('sol1').attach('std1');
model.sol('sol1').create('st1', 'StudyStep');
model.sol('sol1').create('v1', 'Variables');
model.sol('sol1').create('s1', 'Stationary');
model.sol('sol1').feature('s1').create('p1', 'Parametric');
model.sol('sol1').feature('s1').create('fc1', 'FullyCoupled');
model.sol('sol1').feature('s1').feature.remove('fcDef');

model.result.dataset.remove('dset1');

model.sol('sol1').attach('std1');
%model.sol('sol1').feature('s1').set('stol', '0.0001');
model.sol('sol1').feature('s1').feature('p1').active(false);
model.sol('sol1').runAll;

%model.study('std1').feature('stat').set('showdistribute', false);

model.result.dataset.create('dset1', 'Solution');
model.result.dataset('dset1').set('solution', 'sol1');
model.result.create('pg1', 2);
model.result('pg1').set('data', 'dset1');
model.result('pg1').create('surf1', 'Surface');
model.result('pg1').feature('surf1').set('expr', 'u');

model.sol('sol1').runAll;

model.result('pg1').run;

P = mphinterp(model,'u','coord',MAP);

out = P;