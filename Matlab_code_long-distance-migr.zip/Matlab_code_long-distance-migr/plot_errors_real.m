cdir = pwd();
load(strcat(cdir,'/Atlantic_ocean_case/Ascension_with_speed.mat'))
load(strcat(cdir,'/Indian_ocean_case/Somalia_with_speed.mat'))

alphacat = -2:0.1:2;
costcat = -2:0.1:2;
Error_Alpha_Ascension(Error_Alpha_Ascension>max(alphacat))  = max(alphacat)-(alphacat(2)-alphacat(1))/2;
Error_Alpha_Somalia(Error_Alpha_Somalia>max(alphacat))  = max(alphacat)-(alphacat(2)-alphacat(1))/2;
Error_Alpha_Ascension(Error_Alpha_Ascension<min(alphacat))  = min(alphacat)+(alphacat(2)-alphacat(1))/2;
Error_Alpha_Somalia(Error_Alpha_Somalia<min(alphacat))  = min(alphacat)+(alphacat(2)-alphacat(1))/2;

Error_Ratio_Ascension(Error_Ratio_Ascension>max(costcat)) = max(costcat)-(costcat(2)-costcat(1))/2;
Error_Ratio_Somalia(Error_Ratio_Somalia>max(costcat)) = max(costcat)-(costcat(2)-costcat(1))/2;
Error_Ratio_Ascension(Error_Ratio_Ascension<min(costcat)) = min(costcat)+(costcat(2)-costcat(1))/2;
Error_Ratio_Somalia(Error_Ratio_Somalia<min(costcat)) = min(costcat)+(costcat(2)-costcat(1))/2;

subplot(2,2,1)
% histogram(Error_Alpha_Ascension(~isnan(LongAscensiontheo)),alphacat)
% xlim([min(alphacat) max(alphacat)])
% yticks([0 10 20])
ylabel({'Reconstruction of \alpha'})
pie([41 44 5],[0 0 1])
colormap([240 240 240; 192 192 192; 64 64 64]/255)
title('Ascension')


subplot(223)
histogram(Error_Ratio_Ascension(~isnan(LongAscensiontheo)),costcat)
ylabel({'Error in the', 'reconstruction of the','adimensionalized cost ratio'})
xlim([min(costcat) max(costcat)])
yticks([0 20 40])

subplot(2,2,2)
% histogram(Error_Alpha_Somalia(~isnan(LongSomaliatheo)),alphacat)
% xlim([min(alphacat) max(alphacat)])
% yticks([0 5 10])
pie([37 55 2],[0 0 1])
colormap([240 240 240; 192 192 192; 64 64 64]/255)
title('Somalia')

subplot(224)
histogram(Error_Ratio_Somalia(~isnan(LongSomaliatheo)),costcat)
xlim([min(costcat) max(costcat)])
yticks([0 20 40])
